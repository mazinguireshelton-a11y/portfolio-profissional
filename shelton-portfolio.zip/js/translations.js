// js/translations.js - VERSÃO COMPLETAMENTE CORRIGIDA
console.log('🌍 Sistema de Tradução Carregado!');

class TranslationSystem {
    constructor() {
        this.currentLang = this.detectLanguage();
        this.translations = this.getCompleteTranslations();
        this.init();
    }

    getCompleteTranslations() {
        return {
            'pt': {
                // Navegação
                'nav.about': 'Sobre Mim',
                'nav.leadership': 'Liderança',
                'nav.programming': 'Programação',
                'nav.courses': 'Cursos',
                'nav.sports': 'Esportes',

                // Hero Section
                'hero.title': 'Shelton Mazinguire Manuel',
                'hero.tagline': 'Estudante | Programador junior | Líder | Atleta',
                'hero.email': 'shelton.mazinguire@yandex.com',
                'hero.phone': '+258 875962589',
                'hero.location': 'Chimoio, Moçambique',

                // Sobre Mim
                'about.title': 'Sobre Mim',
                'about.journey': '🔄 Minha Jornada',
                'about.journeyText': 'Sou estudante do 12º ano em Chimoio, Moçambique, com paixão por tecnologia, engenharia e inovação. Busco constantemente aprender e aplicar conhecimentos em projetos práticos que possam impactar positivamente minha comunidade.',
                'about.education': '🎓 Formação Acadêmica',
                'about.school': 'Escola Secundária Samora Machel',
                'about.year': '2024 - 2025',
                'about.grade': '12º Ano - Ciências com biológia',
                'about.subjects': 'Matemática, Física e Química, Programação Básica',
                'about.skills': '🛠️ Competências',
                'about.goals': '🎯 Objetivos',
                'about.goal1': 'Graduar-me em Engenharia Mecânica',
                'about.goal2': 'Desenvolver soluções tecnológicas para Moçambique',
                'about.goal3': 'Contribuir para o desenvolvimento industrial',
                'about.goal4': 'Inspirar jovens na área de tecnologia',
                'about.projects': 'Projetos Concluídos',
                'about.certificates': 'Certificados',
                'about.experience': 'Anos de Experiência',

                // Liderança
                'leadership.title': 'Liderança - Young Life',
                'leadership.journey': '🌟 Minha Jornada de Liderança',
                'leadership.journeyText': 'Atuação como líder juvenil na Young Life Moçambique, coordenando atividades, mentorando jovens e desenvolvendo habilidades de comunicação e trabalho em equipe.',
                'leadership.coordination': 'Coordenação de Grupos',
                'leadership.coordinationText': 'Liderança de grupos juvenis com foco no desenvolvimento pessoal e comunitário',
                'leadership.mentoring': 'Mentoria',
                'leadership.mentoringText': 'Orientação e apoio a jovens em suas jornadas educacionais e pessoais',
                'leadership.events': 'Organização de Eventos',
                'leadership.eventsText': 'Planejamento e execução de atividades recreativas e educativas',
                'leadership.gallery': '📸 Galeria - Young Life',

                // Programação
                'programming.title': 'Programação & Projetos',
                'programming.tech': '💻 Tecnologias que Utilizo',
                'programming.projects': '🚀 Meus Projetos no GitHub',
                'programming.github': '🔗 Meu GitHub',
                'programming.visit': 'Visitar Meu GitHub',
                'programming.repos': 'Repositórios',
                'programming.followers': 'Seguidores',

                // Cursos
                'courses.title': 'Cursos & Certificações',
                'courses.header': '📚 Cursos do Alisson que Estou Fazendo',
                'courses.subtitle': 'Desenvolvimento contínuo através de cursos online para aprimorar minhas habilidades técnicas',
                'courses.certificates': '🏆 Meus Certificados',

                // Esportes
                'sports.title': 'Esportes - Handebol',
                'sports.passion': '🏐 Minha Paixão pelo Handebol',
                'sports.passionText': 'Prática regular de handebol competitivo, desenvolvendo disciplina, trabalho em equipe e espírito esportivo através de treinos e competições escolares.',
                'sports.years': 'Anos Jogando',
                'sports.games': 'Jogos Competitivos',
                'sports.awards': 'Premiações',
                'sports.benefits': '🎯 Benefícios do Esporte',
                'sports.moments': '📸 Momentos do Handebol',
                'sports.videos': '🎥 Vídeos dos Jogos',

                // Footer
                'footer.tagline': 'Estudante | Programador | Líder | Atleta',
                'footer.mission': 'Transformando paixão em projetos concretos',
                'footer.connect': 'Conecte-se Comigo',
                'footer.contact': 'Contato',
                'footer.rights': 'Todos os direitos reservados.'
            },

            'en': {
                // Navigation
                'nav.about': 'About Me',
                'nav.leadership': 'Leadership',
                'nav.programming': 'Programming',
                'nav.courses': 'Courses',
                'nav.sports': 'Sports',

                // Hero Section
                'hero.title': 'Shelton Mazinguire Manuel',
                'hero.tagline': 'Student | Junior Programmer | Leader | Athlete',
                'hero.email': 'shelton.mazinguire@yandex.com',
                'hero.phone': '+258 875962589',
                'hero.location': 'Chimoio, Mozambique',

                // About Me
                'about.title': 'About Me',
                'about.journey': '🔄 My Journey',
                'about.journeyText': 'I am a 12th grade student in Chimoio, Mozambique, passionate about technology, engineering and innovation. I constantly seek to learn and apply knowledge in practical projects that can positively impact my community.',
                'about.education': '🎓 Academic Education',
                'about.school': 'Samora Machel Secondary School',
                'about.year': '2024 - 2025',
                'about.grade': '12th Grade - Science with biology',
                'about.subjects': 'Mathematics, Physics and Chemistry, Basic Programming',
                'about.skills': '🛠️ Skills',
                'about.goals': '🎯 Goals',
                'about.goal1': 'Graduate in Mechanical Engineering',
                'about.goal2': 'Develop technological solutions for Mozambique',
                'about.goal3': 'Contribute to industrial development',
                'about.goal4': 'Inspire young people in technology area',
                'about.projects': 'Completed Projects',
                'about.certificates': 'Certificates',
                'about.experience': 'Years of Experience',

                // Leadership
                'leadership.title': 'Leadership - Young Life',
                'leadership.journey': '🌟 My Leadership Journey',
                'leadership.journeyText': 'Acting as a youth leader at Young Life Mozambique, coordinating activities, mentoring young people and developing communication and teamwork skills.',
                'leadership.coordination': 'Group Coordination',
                'leadership.coordinationText': 'Leadership of youth groups focused on personal and community development',
                'leadership.mentoring': 'Mentoring',
                'leadership.mentoringText': 'Guidance and support for young people in their educational and personal journeys',
                'leadership.events': 'Event Organization',
                'leadership.eventsText': 'Planning and execution of recreational and educational activities',
                'leadership.gallery': '📸 Gallery - Young Life',

                // Programming
                'programming.title': 'Programming & Projects',
                'programming.tech': '💻 Technologies I Use',
                'programming.projects': '🚀 My Projects on GitHub',
                'programming.github': '🔗 My GitHub',
                'programming.visit': 'Visit My GitHub',
                'programming.repos': 'Repositories',
                'programming.followers': 'Followers',

                // Courses
                'courses.title': 'Courses & Certifications',
                'courses.header': '📚 Alisson Courses I\'m Taking',
                'courses.subtitle': 'Continuous development through online courses to improve my technical skills',
                'courses.certificates': '🏆 My Certificates',

                // Sports
                'sports.title': 'Sports - Handball',
                'sports.passion': '🏐 My Passion for Handball',
                'sports.passionText': 'Regular practice of competitive handball, developing discipline, teamwork and sportsmanship through training and school competitions.',
                'sports.years': 'Years Playing',
                'sports.games': 'Competitive Games',
                'sports.awards': 'Awards',
                'sports.benefits': '🎯 Sports Benefits',
                'sports.moments': '📸 Handball Moments',
                'sports.videos': '🎥 Game Videos',

                // Footer
                'footer.tagline': 'Student | Programmer | Leader | Athlete',
                'footer.mission': 'Turning passion into concrete projects',
                'footer.connect': 'Connect With Me',
                'footer.contact': 'Contact',
                'footer.rights': 'All rights reserved.'
            },

            'es': {
                // Navegación
                'nav.about': 'Sobre Mí',
                'nav.leadership': 'Liderazgo',
                'nav.programming': 'Programación',
                'nav.courses': 'Cursos',
                'nav.sports': 'Deportes',

                // Hero Section
                'hero.title': 'Shelton Mazinguire Manuel',
                'hero.tagline': 'Estudiante | Programador Junior | Líder | Atleta',
                'hero.email': 'shelton.mazinguire@yandex.com',
                'hero.phone': '+258 875962589',
                'hero.location': 'Chimoio, Mozambique',

                // Sobre Mí
                'about.title': 'Sobre Mí',
                'about.journey': '🔄 Mi Viaje',
                'about.journeyText': 'Soy estudiante de 12º grado en Chimoio, Mozambique, apasionado por la tecnología, ingeniería e innovación. Busco constantemente aprender y aplicar conocimientos en proyectos prácticos que puedan impactar positivamente en mi comunidad.',
                'about.education': '🎓 Formación Académica',
                'about.school': 'Escuela Secundaria Samora Machel',
                'about.year': '2024 - 2025',
                'about.grade': '12º Grado - Ciencias con biología',
                'about.subjects': 'Matemáticas, Física y Química, Programación Básica',
                'about.skills': '🛠️ Habilidades',
                'about.goals': '🎯 Objetivos',
                'about.goal1': 'Graduarme en Ingeniería Mecánica',
                'about.goal2': 'Desarrollar soluciones tecnológicas para Mozambique',
                'about.goal3': 'Contribuir al desarrollo industrial',
                'about.goal4': 'Inspirar a jóvenes en el área de tecnología',
                'about.projects': 'Proyectos Completados',
                'about.certificates': 'Certificados',
                'about.experience': 'Años de Experiencia',

                // Liderazgo
                'leadership.title': 'Liderazgo - Young Life',
                'leadership.journey': '🌟 Mi Viaje de Liderazgo',
                'leadership.journeyText': 'Actuando como líder juvenil en Young Life Mozambique, coordinando actividades, mentorizando jóvenes y desarrollando habilidades de comunicación y trabajo en equipo.',
                'leadership.coordination': 'Coordinación de Grupos',
                'leadership.coordinationText': 'Liderazgo de grupos juveniles enfocado en el desarrollo personal y comunitario',
                'leadership.mentoring': 'Mentoría',
                'leadership.mentoringText': 'Orientación y apoyo a jóvenes en sus viajes educativos y personales',
                'leadership.events': 'Organización de Eventos',
                'leadership.eventsText': 'Planificación y ejecución de actividades recreativas y educativas',
                'leadership.gallery': '📸 Galería - Young Life',

                // Programación
                'programming.title': 'Programación & Proyectos',
                'programming.tech': '💻 Tecnologías que Utilizo',
                'programming.projects': '🚀 Mis Proyectos en GitHub',
                'programming.github': '🔗 Mi GitHub',
                'programming.visit': 'Visitar Mi GitHub',
                'programming.repos': 'Repositorios',
                'programming.followers': 'Seguidores',

                // Cursos
                'courses.title': 'Cursos & Certificaciones',
                'courses.header': '📚 Cursos de Alisson que Estoy Tomando',
                'courses.subtitle': 'Desarrollo continuo a través de cursos en línea para mejorar mis habilidades técnicas',
                'courses.certificates': '🏆 Mis Certificados',

                // Deportes
                'sports.title': 'Deportes - Balonmano',
                'sports.passion': '🏐 Mi Pasión por el Balonmano',
                'sports.passionText': 'Práctica regular de balonmano competitivo, desarrollando disciplina, trabajo en equipo y espíritu deportivo a través de entrenamientos y competencias escolares.',
                'sports.years': 'Años Jugando',
                'sports.games': 'Juegos Competitivos',
                'sports.awards': 'Premios',
                'sports.benefits': '🎯 Beneficios del Deporte',
                'sports.moments': '📸 Momentos del Balonmano',
                'sports.videos': '🎥 Videos de Juegos',

                // Footer
                'footer.tagline': 'Estudiante | Programador | Líder | Atleta',
                'footer.mission': 'Transformando pasión en proyectos concretos',
                'footer.connect': 'Conéctate Conmigo',
                'footer.contact': 'Contacto',
                'footer.rights': 'Todos los derechos reservados.'
            },

            'ru': {
                // Навигация
                'nav.about': 'Обо Мне',
                'nav.leadership': 'Лидерство',
                'nav.programming': 'Программирование',
                'nav.courses': 'Курсы',
                'nav.sports': 'Спорт',

                // Hero Section
                'hero.title': 'Шелтон Мазингире Мануэль',
                'hero.tagline': 'Студент | Младший программист | Лидер | Спортсмен',
                'hero.email': 'shelton.mazinguire@yandex.com',
                'hero.phone': '+258 875962589',
                'hero.location': 'Шимоиу, Мозамбик',

                // Обо Мне
                'about.title': 'Обо Мне',
                'about.journey': '🔄 Мой Путь',
                'about.journeyText': 'Я ученик 12 класса в Шимоиу, Мозамбик, увлекаюсь технологиями, инженерией и инновациями. Постоянно стремлюсь учиться и применять знания в практических проектах, которые могут положительно повлиять на мое сообщество.',
                'about.education': '🎓 Образование',
                'about.school': 'Средняя школа Самора Машел',
                'about.year': '2024 - 2025',
                'about.grade': '12 класс - Естественные науки с биологией',
                'about.subjects': 'Математика, Физика и Химия, Основы программирования',
                'about.skills': '🛠️ Навыки',
                'about.goals': '🎯 Цели',
                'about.goal1': 'Окончить механическое машиностроение',
                'about.goal2': 'Разрабатывать технологические решения для Мозамбика',
                'about.goal3': 'Способствовать промышленному развитию',
                'about.goal4': 'Вдохновлять молодежь в сфере технологий',
                'about.projects': 'Завершенные проекты',
                'about.certificates': 'Сертификаты',
                'about.experience': 'Лет опыта',

                // Лидерство
                'leadership.title': 'Лидерство - Young Life',
                'leadership.journey': '🌟 Мой Путь Лидерства',
                'leadership.journeyText': 'Работаю молодежным лидером в Young Life Мозамбик, координирую мероприятия, наставляю молодежь и развиваю навыки общения и работы в команде.',
                'leadership.coordination': 'Координация групп',
                'leadership.coordinationText': 'Руководство молодежными группами с фокусом на личное и общественное развитие',
                'leadership.mentoring': 'Наставничество',
                'leadership.mentoringText': 'Руководство и поддержка молодежи в их образовательном и личном пути',
                'leadership.events': 'Организация мероприятий',
                'leadership.eventsText': 'Планирование и проведение рекреационных и образовательных мероприятий',
                'leadership.gallery': '📸 Галерея - Young Life',

                // Программирование
                'programming.title': 'Программирование & Проекты',
                'programming.tech': '💻 Технологии которые я использую',
                'programming.projects': '🚀 Мои проекты на GitHub',
                'programming.github': '🔗 Мой GitHub',
                'programming.visit': 'Посетить мой GitHub',
                'programming.repos': 'Репозитории',
                'programming.followers': 'Подписчики',

                // Курсы
                'courses.title': 'Курсы & Сертификации',
                'courses.header': '📚 Курсы Алиссона которые я прохожу',
                'courses.subtitle': 'Постоянное развитие через онлайн курсы для улучшения моих технических навыков',
                'courses.certificates': '🏆 Мои сертификаты',

                // Спорт
                'sports.title': 'Спорт - Гандбол',
                'sports.passion': '🏐 Моя страсть к гандболу',
                'sports.passionText': 'Регулярные занятия конкурентным гандболом, развивая дисциплину, работу в команде и спортивный дух через тренировки и школьные соревнования.',
                'sports.years': 'Лет игры',
                'sports.games': 'Соревновательные игры',
                'sports.awards': 'Награды',
                'sports.benefits': '🎯 Преимущества спорта',
                'sports.moments': '📸 Моменты гандбола',
                'sports.videos': '🎥 Видео игр',

                // Футер
                'footer.tagline': 'Студент | Программист | Лидер | Спортсмен',
                'footer.mission': 'Превращаю страсть в конкретные проекты',
                'footer.connect': 'Свяжитесь со мной',
                'footer.contact': 'Контакт',
                'footer.rights': 'Все права защищены.'
            },

            'zh': {
                // 导航
                'nav.about': '关于我',
                'nav.leadership': '领导力',
                'nav.programming': '编程',
                'nav.courses': '课程',
                'nav.sports': '体育',

                // Hero Section
                'hero.title': '谢尔顿·马津吉尔·曼努埃尔',
                'hero.tagline': '学生 | 初级程序员 | 领导者 | 运动员',
                'hero.email': 'shelton.mazinguire@yandex.com',
                'hero.phone': '+258 875962589',
                'hero.location': '希莫尤, 莫桑比克',

                // 关于我
                'about.title': '关于我',
                'about.journey': '🔄 我的旅程',
                'about.journeyText': '我是莫桑比克希莫尤的12年级学生，热爱技术、工程和创新。我不断寻求学习并将知识应用于实际项目中，以积极影响我的社区。',
                'about.education': '🎓 学历',
                'about.school': '萨莫拉·马谢尔中学',
                'about.year': '2024 - 2025',
                'about.grade': '12年级 - 生物科学',
                'about.subjects': '数学、物理和化学、基础编程',
                'about.skills': '🛠️ 技能',
                'about.goals': '🎯 目标',
                'about.goal1': '获得机械工程学位',
                'about.goal2': '为莫桑比克开发技术解决方案',
                'about.goal3': '为工业发展做出贡献',
                'about.goal4': '激励年轻人进入技术领域',
                'about.projects': '已完成项目',
                'about.certificates': '证书',
                'about.experience': '经验年数',

                // 领导力
                'leadership.title': '领导力 - Young Life',
                'leadership.journey': '🌟 我的领导力旅程',
                'leadership.journeyText': '在莫桑比克Young Life担任青年领袖，协调活动，指导年轻人，发展沟通和团队合作技能。',
                'leadership.coordination': '小组协调',
                'leadership.coordinationText': '领导青年团体，专注于个人和社区发展',
                'leadership.mentoring': '导师指导',
                'leadership.mentoringText': '在教育和个人旅程中为年轻人提供指导和支持',
                'leadership.events': '活动组织',
                'leadership.eventsText': '规划和执行娱乐和教育活动',
                'leadership.gallery': '📸 画廊 - Young Life',

                // 编程
                'programming.title': '编程 & 项目',
                'programming.tech': '💻 我使用的技术',
                'programming.projects': '🚀 我在GitHub上的项目',
                'programming.github': '🔗 我的GitHub',
                'programming.visit': '访问我的GitHub',
                'programming.repos': '仓库',
                'programming.followers': '关注者',

                // 课程
                'courses.title': '课程 & 认证',
                'courses.header': '📚 我正在学习的Alisson课程',
                'courses.subtitle': '通过在线课程持续发展以提高我的技术技能',
                'courses.certificates': '🏆 我的证书',

                // 体育
                'sports.title': '体育 - 手球',
                'sports.passion': '🏐 我对手球的热爱',
                'sports.passionText': '定期练习竞技手球，通过训练和学校比赛培养纪律、团队合作和体育精神。',
                'sports.years': '打球年数',
                'sports.games': '竞技比赛',
                'sports.awards': '奖项',
                'sports.benefits': '🎯 运动益处',
                'sports.moments': '📸 手球时刻',
                'sports.videos': '🎥 比赛视频',

                // 页脚
                'footer.tagline': '学生 | 程序员 | 领导者 | 运动员',
                'footer.mission': '将热情转化为具体项目',
                'footer.connect': '与我联系',
                'footer.contact': '联系方式',
                'footer.rights': '保留所有权利。'
            }
        };
    }

    detectLanguage() {
        const savedLang = localStorage.getItem('preferredLanguage');
        if (savedLang) return savedLang;

        const browserLang = navigator.language.split('-')[0];
        return ['pt', 'en', 'es', 'ru', 'zh'].includes(browserLang) ? browserLang : 'pt';
    }

    init() {
        console.log('🌍 Idioma detectado:', this.currentLang);
        this.setupLanguageSelector();
        this.applyTranslations();
        this.updateLanguageButton();
    }

    setupLanguageSelector() {
        const langBtn = document.querySelector('.lang-btn');
        const dropdown = document.querySelector('.lang-dropdown');
        
        if (langBtn && dropdown) {
            langBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });

            document.addEventListener('click', () => {
                dropdown.classList.remove('show');
            });

            document.querySelectorAll('.lang-option').forEach(option => {
                option.addEventListener('click', (e) => {
                    e.preventDefault();
                    const lang = e.target.getAttribute('data-lang');
                    this.changeLanguage(lang);
                    dropdown.classList.remove('show');
                });
            });

            console.log('✅ Seletor de idiomas configurado');
        } else {
            console.error('❌ Elementos do seletor de idiomas não encontrados');
        }
    }

    changeLanguage(lang) {
        if (this.translations[lang]) {
            this.currentLang = lang;
            localStorage.setItem('preferredLanguage', lang);
            this.applyTranslations();
            this.updateLanguageButton();
            console.log('🔄 Idioma alterado para:', lang);
        }
    }

    updateLanguageButton() {
        const langBtn = document.querySelector('.lang-btn');
        if (!langBtn) return;

        const flags = { 
            'pt': '🇵🇹', 
            'en': '🇺🇸', 
            'es': '🇪🇸', 
            'ru': '🇷🇺', 
            'zh': '🇨🇳' 
        };
        const names = { 
            'pt': 'PT', 
            'en': 'EN', 
            'es': 'ES', 
            'ru': 'RU', 
            'zh': '中文' 
        };
        
        langBtn.innerHTML = `${flags[this.currentLang]} ${names[this.currentLang]}`;
    }

    applyTranslations() {
        console.log('🔄 Aplicando traduções para:', this.currentLang);
        
        // Traduzir elementos com data-key
        const elements = document.querySelectorAll('[data-key]');
        elements.forEach(element => {
            const key = element.getAttribute('data-key');
            const translation = this.getTranslation(key);
            
            if (translation && translation !== key) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else if (element.tagName === 'A' && (element.href.startsWith('mailto:') || element.href.startsWith('tel:'))) {
                    element.textContent = translation;
                } else {
                    element.textContent = translation;
                }
            }
        });

        // Traduzir elementos especiais sem data-key
        this.translateSpecialElements();
        
        console.log('✅ Traduções aplicadas!');
    }

    translateSpecialElements() {
        const specialElements = [
            // Hero Section
            { selector: '.hero h1', key: 'hero.title' },
            { selector: '.tagline', key: 'hero.tagline' },
            { selector: '.contact-info a[href^="mailto"]', key: 'hero.email', attr: 'text' },
            { selector: '.contact-info a[href^="tel"]', key: 'hero.phone', attr: 'text' },
            { selector: '.contact-info span:last-child', key: 'hero.location' },
            
            // Section Titles
            { selector: '#sobre .section-title', key: 'about.title' },
            { selector: '#lideranca .section-title', key: 'leadership.title' },
            { selector: '#programacao .section-title', key: 'programming.title' },
            { selector: '#cursos .section-title', key: 'courses.title' },
            { selector: '#esportes .section-title', key: 'sports.title' },
            
            // About Me Section
            { selector: '.intro-card h3', key: 'about.journey' },
            { selector: '.intro-card p', key: 'about.journeyText' },
            { selector: '.education-card h3', key: 'about.education' },
            { selector: '.education-item h4', key: 'about.school' },
            { selector: '.education-item .year', key: 'about.year' },
            { selector: '.education-item p', key: 'about.grade' },
            { selector: '.skills-card h3', key: 'about.skills' },
            { selector: '.goals-card h3', key: 'about.goals' },
            { selector: '.stats-card .stat:nth-child(1) .stat-label', key: 'about.projects' },
            { selector: '.stats-card .stat:nth-child(2) .stat-label', key: 'about.certificates' },
            { selector: '.stats-card .stat:nth-child(3) .stat-label', key: 'about.experience' },
            
            // Leadership Section
            { selector: '.lideranca-intro h3', key: 'leadership.journey' },
            { selector: '.lideranca-intro p', key: 'leadership.journeyText' },
            { selector: '.atividade-card:nth-child(1) h4', key: 'leadership.coordination' },
            { selector: '.atividade-card:nth-child(1) p', key: 'leadership.coordinationText' },
            { selector: '.atividade-card:nth-child(2) h4', key: 'leadership.mentoring' },
            { selector: '.atividade-card:nth-child(2) p', key: 'leadership.mentoringText' },
            { selector: '.atividade-card:nth-child(3) h4', key: 'leadership.events' },
            { selector: '.atividade-card:nth-child(3) p', key: 'leadership.eventsText' },
            { selector: '.galeria-section h3', key: 'leadership.gallery' },
            
            // Programming Section
            { selector: '.tech-stack h3', key: 'programming.tech' },
            { selector: '.projetos-section h3', key: 'programming.projects' },
            { selector: '.github-links h3', key: 'programming.github' },
            { selector: '.github-btn', key: 'programming.visit' },
            { selector: '.stats .stat:nth-child(1)', key: 'programming.repos', prefix: 'Repositórios: ' },
            { selector: '.stats .stat:nth-child(2)', key: 'programming.followers', prefix: 'Seguidores: ' },
            
            // Courses Section
            { selector: '.cursos-header h3', key: 'courses.header' },
            { selector: '.cursos-header p', key: 'courses.subtitle' },
            { selector: '.certificados-section h3', key: 'courses.certificates' },
            
            // Sports Section
            { selector: '.esportes-content h3', key: 'sports.passion' },
            { selector: '.esportes-content p', key: 'sports.passionText' },
            { selector: '.esporte-stat:nth-child(1) .esporte-label', key: 'sports.years' },
            { selector: '.esporte-stat:nth-child(2) .esporte-label', key: 'sports.games' },
            { selector: '.esporte-stat:nth-child(3) .esporte-label', key: 'sports.awards' },
            { selector: '.esportes-beneficios h4', key: 'sports.benefits' },
            { selector: '.galeria-esportes h3', key: 'sports.moments' },
            { selector: '.videos-section h3', key: 'sports.videos' },
            
            // Footer
            { selector: '.footer-info p:nth-child(2)', key: 'footer.tagline' },
            { selector: '.footer-info p:nth-child(3)', key: 'footer.mission' },
            { selector: '.footer-links h4', key: 'footer.connect' },
            { selector: '.footer-contact h4', key: 'footer.contact' },
            { selector: '.footer-bottom p', key: 'footer.rights' }
        ];

        specialElements.forEach(item => {
            const elements = document.querySelectorAll(item.selector);
            elements.forEach(element => {
                const translation = this.getTranslation(item.key);
                if (translation && element.textContent) {
                    if (item.attr === 'text') {
                        if (element.tagName === 'A') {
                            const href = element.getAttribute('href');
                            if (href && href.startsWith('mailto:')) {
                                element.textContent = translation;
                            } else if (href && href.startsWith('tel:')) {
                                element.textContent = translation;
                            }
                        }
                    } else if (item.prefix) {
                        element.textContent = item.prefix + translation;
                    } else {
                        element.textContent = translation;
                    }
                }
            });
        });
    }

    getTranslation(key) {
        return this.translations[this.currentLang]?.[key] || this.translations['pt']?.[key] || key;
    }
}

// Inicializar quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Iniciando sistema de tradução...');
    window.translationSystem = new TranslationSystem();
});

// Prevenir erros
if (typeof window.translationSystem === 'undefined') {
    document.addEventListener('DOMContentLoaded', function() {
        window.translationSystem = new TranslationSystem();
    });
}
