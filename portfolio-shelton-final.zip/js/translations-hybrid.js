// js/translations-hybrid.js - SISTEMA QUE REALMENTE FUNCIONA
console.log('🌍 SISTEMA DE TRADUÇÃO PRÁTICO INICIADO!');

class WorkingTranslationSystem {
    constructor() {
        this.baseLang = 'pt';
        this.currentLang = this.detectLanguage();
        this.init();
    }

    init() {
        console.log('🚀 Iniciando sistema prático...');
        
        // CONFIGURAÇÃO CORRETA: Deixa o navegador traduzir naturalmente
        this.setupCorrectLanguage();
        
        this.setupLanguageSelector();
        this.updateLanguageButton();
        
        console.log('✅ Sistema prático pronto! Navegador pode traduzir.');
    }

    detectLanguage() {
        const savedLang = localStorage.getItem('preferredLanguage');
        const urlParams = new URLSearchParams(window.location.search);
        const urlLang = urlParams.get('lang');
        
        return urlLang || savedLang || this.baseLang;
    }

    setupCorrectLanguage() {
        console.log('🔧 Configurando idioma corretamente...');
        
        // 1. Define o idioma base CORRETAMENTE
        document.documentElement.lang = 'pt';
        
        // 2. REMOVE qualquer bloqueio à tradução
        this.removeTranslationBlocks();
        
        // 3. Adiciona sinais sutis para o navegador
        this.addTranslationHints();
    }

    removeTranslationBlocks() {
        // Remove meta tags que bloqueiam tradução
        const badMeta = document.querySelector('meta[name="google"][content="notranslate"]');
        if (badMeta) {
            badMeta.remove();
            console.log('✅ Meta tag bloqueadora removida');
        }
        
        // Remove qualquer classe/style que impeça tradução
        document.body.classList.remove('notranslate', 'translation-blocked');
        document.body.style.cssText = document.body.style.cssText.replace('translate: none', '');
    }

    addTranslationHints() {
        // Adiciona meta tag que PERMITE tradução
        if (!document.querySelector('meta[name="google"][content="translate"]')) {
            const meta = document.createElement('meta');
            meta.name = 'google';
            meta.content = 'translate';
            document.head.appendChild(meta);
            console.log('✅ Meta tag de tradução adicionada');
        }
        
        // Garante que o conteúdo seja detectável
        document.body.setAttribute('translate', 'yes');
    }

    setupLanguageSelector() {
        const langBtn = document.querySelector('.lang-btn');
        const dropdown = document.querySelector('.lang-dropdown');

        if (langBtn && dropdown) {
            console.log('✅ Elementos do seletor encontrados');
            
            langBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('show');
            });

            dropdown.querySelectorAll('.lang-option').forEach(option => {
                option.addEventListener('click', (e) => {
                    e.preventDefault();
                    const lang = option.getAttribute('data-lang');
                    console.log('🎯 Idioma selecionado:', lang);
                    this.changeToLanguage(lang);
                    dropdown.classList.remove('show');
                });
            });

            document.addEventListener('click', (e) => {
                if (!langBtn.contains(e.target) && !dropdown.contains(e.target)) {
                    dropdown.classList.remove('show');
                }
            });
        }
    }

    changeToLanguage(lang) {
        console.log(`🔄 Mudando para: ${lang}`);
        
        this.currentLang = lang;
        localStorage.setItem('preferredLanguage', lang);
        this.updateLanguageButton();
        
        // Método SIMPLES que funciona
        this.simpleLanguageChange(lang);
    }

    simpleLanguageChange(lang) {
        if (lang === 'pt') {
            // Para português: apenas recarrega limpo
            window.location.href = window.location.pathname;
        } else {
            // Para outros idiomas: mostra mensagem amigável
            this.showTranslationInstructions(lang);
        }
    }

    showTranslationInstructions(lang) {
        const langNames = {
            'en': 'Inglês',
            'es': 'Espanhol', 
            'ru': 'Russo',
            'zh': 'Chinês'
        };
        
        const message = `
🎯 Como traduzir para ${langNames[lang]}:

1. Clique com o BOTÃO DIREITO em qualquer lugar da página
2. Selecione "Traduzir para ${langNames[lang]}"
3. Ou clique no ícone de tradução 🌐 na barra de endereço

💡 Dica: O navegador traduzirá automaticamente nas próximas visitas!
        `;
        
        alert(message);
        console.log('📝 Instruções mostradas para:', lang);
    }

    updateLanguageButton() {
        const langBtn = document.querySelector('.lang-btn');
        const dropdownOptions = document.querySelectorAll('.lang-option');
        if (!langBtn) return;

        const flags = { 'pt': '🇵🇹', 'en': '🇺🇸', 'es': '🇪🇸', 'ru': '🇷🇺', 'zh': '🇨🇳' };
        const names = { 'pt': 'PT', 'en': 'EN', 'es': 'ES', 'ru': 'RU', 'zh': '中文' };
        
        const flag = flags[this.currentLang] || '🌐';
        const name = names[this.currentLang] || this.currentLang.toUpperCase();
        
        langBtn.innerHTML = `${flag} ${name}`;
        
        dropdownOptions.forEach(option => {
            option.classList.remove('active');
            if (option.getAttribute('data-lang') === this.currentLang) {
                option.classList.add('active');
            }
        });
    }
}

// REMOVA esta meta tag do seu HTML:
// <meta name="google" content="notranslate">

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM Carregado - Iniciando sistema prático...');
    window.translationSystem = new WorkingTranslationSystem();
});
